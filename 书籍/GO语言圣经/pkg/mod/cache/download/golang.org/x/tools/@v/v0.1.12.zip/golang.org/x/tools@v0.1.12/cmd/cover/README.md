# Deprecated

NOTE: For Go releases 1.5 and later, this tool lives in the standard repository. The code here is not maintained.
